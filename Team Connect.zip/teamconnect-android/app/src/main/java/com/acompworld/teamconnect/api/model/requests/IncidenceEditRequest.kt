package com.acompworld.teamconnect.api.model.requests

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class IncidenceEditRequest(
    val incidenceid:Int?,
    val incidencetitle:String?,
    val date:String?,
    val time:String?,
    val area:String?,
    val type:String?,
    val details:String?
)
