package com.acompworld.teamconnect.api.model.responses

import com.acompworld.teamconnect.api.model.entities.IncidenceDetail

data class IncidenceDetailResponse(
    val `data`: IncidenceDetail,
    val status: String
)
