package com.acompworld.teamconnect.api.model.responses

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class IncidenceEditResponse(
    val message: String?,
    val status: String?
)
