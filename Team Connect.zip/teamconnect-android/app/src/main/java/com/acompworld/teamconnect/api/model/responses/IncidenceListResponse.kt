package com.acompworld.teamconnect.api.model.responses

import com.acompworld.teamconnect.api.model.entities.Data

data class IncidenceListResponse(
    val `data`: List<Data>
)
