package com.acompworld.teamconnect.ui.fragments.incidence

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkRequest
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.acompworld.teamconnect.api.model.requests.IncidenceEditRequest
import com.acompworld.teamconnect.api.model.responses.IncidenceDetailResponse
import com.acompworld.teamconnect.api.model.responses.IncidenceEditResponse
import com.acompworld.teamconnect.repo.TeamConnectRepository
import com.acompworld.teamconnect.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class IncidenceViewModel @Inject constructor(
    val cm: ConnectivityManager,
    val repo: TeamConnectRepository
) : ViewModel() {
    private var hasIntentConnection: Boolean = false
    private val builder = NetworkRequest.Builder()
    private var initiallyCalledDetails: Boolean = false
    private var initiallyCalledEdit: Boolean = false
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            super.onAvailable(network)
            hasIntentConnection = true
        }

        override fun onLost(network: Network) {
            super.onLost(network)
            hasIntentConnection = false
        }
    }

    init {
        cm.registerNetworkCallback(builder.build(), networkCallback)
    }

    private val _incidenceDetail = MutableLiveData<Resource<IncidenceDetailResponse?>>()
    val incidenceDetail: LiveData<Resource<IncidenceDetailResponse?>> = _incidenceDetail

    private val _incidenceEdit = MutableLiveData<Resource<IncidenceEditResponse?>>()
    var incidenceEdit: LiveData<Resource<IncidenceEditResponse?>> = _incidenceEdit

    fun getIncidenceDetailById(projectCode: String, incidenceID: Int) = viewModelScope.launch {
        initiallyCalledDetails = true
        _incidenceDetail.postValue(Resource.loading(_incidenceDetail.value?.data))
        try {
            delay(150)
            // CHANGE EVERY RED HIGHLIGHTS
            if (hasIntentConnection) {
                val response = repo.getIncidenceDetail(projectCode, incidenceID)
                handleIncidenceResource(response)
            } else _incidenceDetail.postValue(
                Resource.error(
                    data = _incidenceDetail.value?.data,
                    msg = "No Internet Connection...!"
                )
            )
        } catch (e: Exception) {
            _incidenceDetail.postValue(
                Resource.error(
                    data = _incidenceDetail.value?.data,
                    msg = e.message ?: "Something went Wrong"
                )
            )
        }
    }

    private fun handleIncidenceResource(response: Response<IncidenceDetailResponse>) {
        if (response.isSuccessful)
            _incidenceDetail.postValue(Resource.success(response.body()))
        else _incidenceDetail.postValue(
            Resource.error(
                data = _incidenceDetail.value?.data,
                msg = response.message() ?: "Error ${response.code()} found...!"
            )
        )
    }

    fun editIncidence(
        incidenceID: Int? , incidenceTitle: String, incidenceDate: String,
        incidenceTime: String , incidenceArea: String , incidenceType: String,
        incidenceDetail: String
    ) = viewModelScope.launch {
        initiallyCalledEdit = true
        _incidenceEdit.postValue((Resource.loading(_incidenceEdit.value?.data)))
        try {
            if (hasIntentConnection) {
                val editRequest = IncidenceEditRequest(
                    incidenceID, incidenceTitle, incidenceDate, incidenceTime,
                    incidenceArea, incidenceType, incidenceDetail
                )
                Log.i("viewModel", "editIncidence: "+editRequest.toString())
                val response = repo.editIncidence(editRequest)
                handleEditResource(response)
            } else {
                _incidenceEdit.postValue(
                    Resource.error(
                        data = _incidenceEdit.value?.data,
                        msg = "No Internet Connection"
                    )
                )
            }
        } catch (e: Exception) {
            _incidenceEdit.postValue(
                Resource.error(
                    data = _incidenceEdit.value?.data,
                    msg = e.message ?: "Something went wrong"
                )
            )
        }


    }

    private fun handleEditResource(response: Response<IncidenceEditResponse>) {
        if (response.isSuccessful) {
            _incidenceEdit.postValue(Resource.success(response.body()!!))
        } else {
            var obj = JSONObject(response.errorBody()?.string())
            _incidenceEdit.postValue(
                Resource.error(
                    data = _incidenceEdit.value?.data,
                    msg = obj?.getString("message") ?: "Error ${response.code()} found...!"
                )
            )
        }

    }


}

