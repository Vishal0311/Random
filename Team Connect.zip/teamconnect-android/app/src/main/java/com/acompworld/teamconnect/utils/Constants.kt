package com.acompworld.teamconnect.utils

object Constants {

    val SEARCH_TIME_DELAY:Long = 500L
    const val EMPLYOYEE_ID = "emp_id"

    const val KEY_FILE = "url of the file"

    const val KEY_DEPT_ID= "departmentId"

    const val KEY_RID = "rid"

    const val  TELEPHONE_CONTACT_ID = "tele_phn_id"

    const val  PROJECT_Code = "project_code"

    const val KEY_ALBUM_ID= "album id"

    const val  KEY_DEPARTMENT = " department ki  chabbi"

    const val KEY_SECTION  = "type"

    const val LMS_PHOTO_BASE_URL = ""


}